<?php
session_start();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sinergi Pariwisata Garut</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f7f9fb;
        }
        .hero {
            background-image: url('https://assets.pikiran-rakyat.com/photo/2024/05/19/1906008294.jpg');
            color: white;
            
            padding: 180px 30px;
            border-radius: 10px;
            background-size: cover;
            background-position: center;
        }
        .menu-card {
            background-color: white;
            border: 1px solid #e0e0e0;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            transition: 0.3s;
        }
        .menu-card:hover {
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
            transform: translateY(-4px);
        }
        .menu-card i {
            font-size: 36px;
            margin-bottom: 10px;
            color: #00aaff;
        }
        footer {
            margin-top: 50px;
            padding: 20px;
            background-color: #f0f0f0;
            text-align: center;
            font-size: 14px;
            color: #555;
        }
    </style>
    <script src="https://kit.fontawesome.com/a2e8a13c8a.js" crossorigin="anonymous"></script>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php">🌄 Sinergi Pariwisata Garut</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="index.php">Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="tentangkita.php">Tentang Kami</a></li>
                <li class="nav-item"><a class="nav-link" href=  "admin.php">Admin</a></li>
                <?php if (isset($_SESSION['username'])): ?>
                    <li class="nav-item"><a class="nav-link" href="#">👤 <?= $_SESSION['username'] ?></a></li>
                    <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="hero text-center mb-5">
        <h1 class="display-5 fw-bold">🌄 Sinergi Pariwisata Garut</h1>
        <p class="lead">Temukan pengalaman wisata terbaik di Garut — beli tiket, pesan penginapan, dan banyak lagi.</p>
    </div>

<div id="promoCarousel" class="carousel slide mb-5" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <div class="card mx-auto shadow-sm" style="max-width: 1000px;">
                <img src="assets/promo11.png" class="card-img-top" alt="Promo 1">
                <div class="card-body text-center">
                </div>
            </div>
        </div>
        <div class="carousel-item">
            <div class="card mx-auto shadow-sm" style="max-width: 1000px;">
                <img src="assets/promo22.png" class="card-img-top" alt="Promo 2">
                <div class="card-body text-center">
                </div>
            </div>
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#promoCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#promoCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
    </button>
</div>


    <div class="row g-4">
        <?php
        $menu = [
            'Beli Tiket' => ['link' => 'beli_tiket.php', 'icon' => 'fa-ticket'],
            'Paket Wisata' => ['link' => 'paket_wisata.php', 'icon' => 'fa-suitcase-rolling'],
            'Lokasi Wisata' => ['link' => 'lokasi_wisata.php', 'icon' => 'fa-map-marked-alt'],
            'Agen Wisata' => ['link' => 'agen_wisata.php', 'icon' => 'fa-building'],
            'Penginapan' => ['link' => 'penginapan.php', 'icon' => 'fa-hotel'],
            'Pemesanan' => ['link' => 'pemesanan.php', 'icon' => 'fa-calendar-check'],
            'Pembayaran' => ['link' => 'pembayaran.php', 'icon' => 'fa-credit-card'],
            'Tour Guide' => ['link' => 'tour_guide.php', 'icon' => 'fa-user-tie'],
            'Feedback' => ['link' => 'feedback.php', 'icon' => 'fa-comments'],
        ];

        foreach ($menu as $label => $data) {
            echo "
            <div class='col-6 col-md-4 col-lg-3'>
                <a href='{$data['link']}' class='text-decoration-none text-dark'>
                    <div class='menu-card h-100'>
                        <i class='fas {$data['icon']}'></i>
                        <h6 class='mt-2'>{$label}</h6>
                    </div>
                </a>
            </div>";
        }
        ?>
    </div>
</div>

<footer>
    <div>© <?= date('Y') ?> Sinergi Pariwisata Garut. Dibuat dengan ❤️ oleh SASENANA.</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
